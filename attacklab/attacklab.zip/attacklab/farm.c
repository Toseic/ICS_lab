/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_305(unsigned x)
{
    return x + 3267856712U;
}

unsigned getval_467()
{
    return 3281017083U;
}

unsigned getval_424()
{
    return 3351742792U;
}

void setval_156(unsigned *p)
{
    *p = 3347662928U;
}

unsigned addval_487(unsigned x)
{
    return x + 1209062098U;
}

unsigned addval_314(unsigned x)
{
    return x + 2425393240U;
}

unsigned getval_185()
{
    return 1812251224U;
}

void setval_198(unsigned *p)
{
    *p = 3347662958U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_188(unsigned *p)
{
    *p = 2425667977U;
}

unsigned getval_147()
{
    return 3223374465U;
}

unsigned getval_112()
{
    return 2445379930U;
}

unsigned addval_123(unsigned x)
{
    return x + 3224947337U;
}

unsigned addval_208(unsigned x)
{
    return x + 3380920712U;
}

void setval_442(unsigned *p)
{
    *p = 2429192530U;
}

unsigned addval_141(unsigned x)
{
    return x + 3767027848U;
}

void setval_366(unsigned *p)
{
    *p = 3223377545U;
}

unsigned addval_388(unsigned x)
{
    return x + 3269495112U;
}

void setval_369(unsigned *p)
{
    *p = 3372799689U;
}

unsigned getval_200()
{
    return 700700169U;
}

void setval_353(unsigned *p)
{
    *p = 3531915657U;
}

unsigned addval_151(unsigned x)
{
    return x + 3229931145U;
}

unsigned addval_374(unsigned x)
{
    return x + 3286280520U;
}

unsigned addval_364(unsigned x)
{
    return x + 3223374537U;
}

unsigned getval_284()
{
    return 3525367305U;
}

void setval_425(unsigned *p)
{
    *p = 3526934921U;
}

unsigned getval_435()
{
    return 3281114761U;
}

void setval_324(unsigned *p)
{
    *p = 3767093275U;
}

unsigned getval_309()
{
    return 3375945225U;
}

unsigned addval_357(unsigned x)
{
    return x + 3674259849U;
}

void setval_177(unsigned *p)
{
    *p = 3269495112U;
}

void setval_465(unsigned *p)
{
    *p = 3676357005U;
}

void setval_398(unsigned *p)
{
    *p = 3286272072U;
}

void setval_125(unsigned *p)
{
    *p = 3229928089U;
}

void setval_473(unsigned *p)
{
    *p = 3674265225U;
}

unsigned getval_390()
{
    return 3373845129U;
}

void setval_168(unsigned *p)
{
    *p = 3225993609U;
}

void setval_348(unsigned *p)
{
    *p = 3767093464U;
}

unsigned addval_251(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_289()
{
    return 3676359321U;
}

unsigned getval_269()
{
    return 3225995913U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
